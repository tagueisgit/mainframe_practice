2006/09/12 @kl ASP on MVT distribution README
---------------------------------------------


This package is a turnkey system consisting of MVT Release 21.8
with ASP Version 3.2 installed on it.  It contains support
files including Hercules configuration, basic documentation,
various jobstreams and distribution tapes, as well as DASD
image files with the system installed and ready to run.


Installation:
-------------

Unzip the distribution file.  This will create the directory
structure:

    asp/
      conf/
      ctl/
      dasd/
      doc/
      haspjcl/
      ivp/
      jcl/
      log/
      prt/
      pun/
      source/
      standalone/
      sysgen/
      tape/
      usermods/

Some subdirectories, including prt and pun, are intended for
operational use and are initially empty.


Startup:
--------

1.   From the asp directory, start Hercules:

      hercules -f conf/asp.conf

2.   Using a 3270 emulator, start a telnet session to port 3270 for
     device 010.  This is the OS master console.  It must be defined
     and connected at IPL, or the IPL will hang.

3.   Using a 3270 emulator, start a telnet session to port 3270 for
     device 014.  This will be the ASP console.

4.   IPL 150.  Messages will appear on the master console 010:

      IEA218I MOD=158 ASSUMED S370
      IEA101A  SPECIFY SYSTEM PARAMETERS FOR RELEASE 21.8F MVT

     Press <enter>.

5.   More messages will appear,ending with message IEE114A:

      IEE140I SYSTEM CONSOLES
        CONSOLE/ALT  COND AUTH     ID AREA  ROUTCD
          30E/010     H   CMDS     06       ALL
          010/02F     M   ALL      01 Z     ALL
          02F/010     N   ALL      02       ALL
          011/010     N   ALL      03 Z     ALL
          009/01F     N   ALL      04       ALL
          01F/009     N   ALL      05       ALL
          30E/010     A   NONE     06       NONE
      IEE101A READY
     *00 IEE114A DATE=78.255,CLOCK=14.54.42 - REPLY WITH SET PARAMETERS OR U

6.   Reply "U" to message IEE114A:

      r 0,u

7.   ASP will be started automatically:

      IEE600I REPLY TO 00 IS; U
      IEE118I SET PARAMETER(S) ACCEPTED
      IEE252I MEMBER COMMND00 FOUND IN SYS1.PARMLIB
      IEE351I SMF SYS1.MAN RECORDING NOT BEING USED
      IEF403I ASP      STARTED    TIME=14.56.14

8.   ASP will switch the master console function to pseudodevice 02F to
     permit it to intercept and process console messages.  Device 010
     will go blank, and ASP console 014 will display:

      145615   INT02 ASP SYSTEM RESTART, ASP 3.2.0
      145615   CNS02 I/O ERROR ON CN01F    STATUS-0200 SENSE-40 OP-09
      145615  *CNS01 CN01F    INACTIVE - INTVN.REQD.
      145615   ASP1 R= IEE143I OLD=010          NEW=02F         VALDCMD= ALL
      145615
      145615   ASP1 R= IEE143I ROUTCDE=ALL
      145615     T=M H=N

9.   Issue the *START,JSS command on the ASP console to start ASP processing:

      *s,jss

10.  ASP will start the maintask MT, which serves as its interface with the
     operating system.  Messages similar to the following will appear on
     the ASP console 014:

      150217   IJP01 JOB=0002 READY FOR DATA FROM IJASP1
      150217  *ASP1 R=*IEA000A  00C,INT REQ,42,0E40,1000,,,ASP
      150217   ASP1 R= IEE341I MT       NOT ACTIVE
      150217   ASP1 R= IEF403I MT       STARTED    TIME=15.02.17
      150217   ASP1 R= IEF234E R 660,,MT
      150217   ASP1 R= IEF234E R 661,,MT
      150217   ASP1 R= IEF234E R 662,,MT
      150217   ASP1 R= IEF234E R 663,,MT
      150217   ASP1 R= IEF234E R 664,,MT
      150217   ASP1 R=          AMTK04 MT INIT COMPLETE
      150217   01 IECASP0 663 IS MT                 MT      ASPQWTR
      150217   02 IECASP0 662 IS MT                 MT      ASPQRDR
      150217   ASP1 R=          MTFN010 DYNAMIC AREA
      150217   ASP1 R=          MTFN012   ASP      00512K  770800  7F0800  ASP
      150217     ASP
      150217   ASP1 R=          MTFN012   MT       00128K  750800  770800  MT
      150217     MT
      150217   ASP1 R=          MTFN011   FBQE     07270K  037000  750800
      150217   ASP1 R=          MTFN013 MINPART IS 00068K, MAXSIZE IS 07270K
      150217   ASP1 R=          IEE318I          QUEUE EMPTY
      150218   ASP1 R=          IEE316I @@       JOB NOT FOUND

     When MT initialization is complete, ASP will issue the message:

      150219   AMSV68 ***** IPL COMPLETE ***** FOR ASP1

     ASP is now ready for processing.


Shutdown:
---------

1.   To ensure that MVT will shut down cleanly, you must first stop
     the maintask MT before stopping ASP.  On the ASP console 014,
     issue the commands:

      f mt,p=a
      p mt

     MT will stop, although you will not see any messages that say so.

2.   Shut down ASP by issuing the *RETURN command:

      *return

     ASP will shut down and restore the OS master console to 010.  On
     010, you will see messages to that effect:

      IEE143I OLD=02F          NEW=010         VALDCMD= ALL
      IEE143I ROUTCDE=ALL                                           T=M H=N
      INTK03 ASP TERMINATION COMPLETE
      IEF404I ASP      ENDED      TIME=15.12.04

     The system may now be stopped.


Notes:
------

1.   You may issue both OS commands and ASP commands using the ASP
     console.   Some messages that normally appear on an OS console,
     like the IEE600I REPLY TO nn message, won't be displayed by ASP
     because ASP selectively suppresses messages.

2.   If the ASP console screen fills up, you will see the message

      *** DISPLAY HALTED - CLEAR TO RESTART ***

     at the bottom of the screen.  To resume message display immediately,
     press the <clear> key.  If you don't, ASP will automatically clear the
     screen in 15 seconds.

3.   A 1052 console is defined at 01F, shared by OS and ASP.  If 01F
     is not present, ASP will eventually "switch" the ASP console
     function from 01F to 014.  This results in a block of duplicate
     messages being sent to 014, one time only.  It's mildly annoying
     but not dangerous.

4.   See the file "aspcommands.txt" in the doc directory for a brief
     description of ASP commands.  File "mtcommands.txt" contains a
     brief summary of maintask (MT) commands.  File "firstipl.txt"
     contains considerations for the first IPL after sysgen.  The
     distributed system has already been IPLed; you will not need
     to perform the documented steps unless you generate your own
     system.

5.   Three 3270 terminals are defined to TCAM for TSO use:  0C0, 0C1
     and 3C0.   You must start TCAM and TSO manually.  TSO user HERC01
     is defined with no password and ACCT, OPER and JCL privileges.

6.   The system contains HASP Version 4 as well as ASP.  To run with HASP
     instead of ASP, reply "AUTO=N" to message IEE114A after IPL:

      r 0,auto=n

     HASP will start:

      IEE600I REPLY TO 00 IS; AUTO=N
      IEE118I SET PARAMETER(S) ACCEPTED
      IEE252I MEMBER COMMND01 FOUND IN SYS1.PARMLIB
      IEE037I LOG NOT SUPPORTED.
      IEE351I SMF SYS1.MAN RECORDING NOT BEING USED
      IEF403I HASP     STARTED    TIME=15.21.46
     *01 $ SPECIFY HASP OPTIONS -- HASP-II VERSION 4.009762

     Reply "WARM,NOREQ"

      r 1,warm,noreq
      IEE600I REPLY TO 01 IS; WARM,NOREQ
      15.22.00 MAXIMUM OF 2  PRINTER(S) EXCEEDED
      15.22.00 IEF403I HOSRDR   STARTED    TIME=15.22.00
     $15.22.00 PRINTER1 IDLE - CLASS=AJ
     $15.22.00 PRINTER2 IDLE - CLASS=AJ
     $15.22.00 PUNCH1   IDLE - CLASS=BK
     $15.22.00 PUNCH1   IDLE - CLASS=BK
      15.22.01 IEF403I HOSBRDR  STARTED    TIME=15.22.01
      15.22.01 IEF403I INIT     STARTED    TIME=15.22.01
      15.22.01 IEF403I INIT     STARTED    TIME=15.22.01
      15.22.01 IEF403I INIT     STARTED    TIME=15.22.01
     $15.22.01 INIT 1  IDLE-CLASS=RA9
     $15.22.01 INIT 2  IDLE-CLASS=RA9
     $15.22.01 INIT 3  IDLE-CLASS=RA9
     $15.22.01 ALL AVAILABLE FUNCTIONS COMPLETE

     HASP is now ready for work.  Issue the "$PHASP" command to stop HASP:

      $phasp
      IEF404I HASP     ENDED      TIME=15.22.21
      IEF404I INIT     ENDED      TIME=15.22.21
      IEF404I INIT     ENDED      TIME=15.22.21
      IEF404I INIT     ENDED      TIME=15.22.21
      IEF404I HOSBRDR  ENDED      TIME=15.22.21
      IEF161I 700-READER CLOSED
      IEF404I HOSRDR   ENDED      TIME=15.22.22

7.   ASP support for TSO SUBMIT, STATUS and CANCEL is included.  The
     STATUS/CANCEL support is incompatible with HASP or vanilla MVT.
     If you issue STATUS jjj with ASP inactive, your TSO session will
     hang.

8.   ASP recognizes "8" as a synonym for its "*" command character.
     Thus the command:

      8s,jss

     is equivalent to

      *s,jss

     In addition, the comma separating the command verb and its
     operand may be replaced by exactly one space.  So the following:

      8s jss
      *s jss

     are also equivalent to "*s,jss".

9.   ASP device setup attempts to determine when analyzing a job's
     tape requirements whether the tape is being used for input or
     output.  If the tape is being used for input, ASP insists that
     it be mounted with NO RING.  In Hercules terms, that means the
     underlying tape AWS or HET file must be marked as read-only.

10.  SYSOUT class Z MSGCLASS output from started tasks and TSO logons
     will collect in the OS queue.  To get rid of the OS SYSOUT class Z
     output, start WTRZ:

      s wtrz

     which will send all class Z output to the bit bucket.  When all
     output has been processed, WTRZ will issue the message:

      IEF868I WTR WTR WAITING FOR WORK

     Issue an OS STOP command to stop WTRZ:

       p wtrz

