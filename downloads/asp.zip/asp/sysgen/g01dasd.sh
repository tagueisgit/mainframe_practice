#!/bin/sh
# i01dasd
# 2006/08/28 @kl build empty disks for MVT ASP sysgen

# ---- aspres.150.cckd ----
dasdload -a ../ctl/aspres.ctl ../dasd/aspres.150
dasdcopy -a -o CCKD ../dasd/aspres.150 ../dasd/aspres.150.cckd
rm -rf ../dasd/aspres.150

 ---- aspsup.151.cckd ----
dasdload -a ../asp/ctl/aspsup.ctl ../asp/dasd/aspsup.151
dasdcopy -a -o CCKD ../asp/dasd/aspsup.151 ../asp/dasd/aspsup.151.cckd
rm -rf ../asp/dasd/aspsup.151

# ---- aspqvs.154.cckd ----
dasdload -a ../ctl/aspqvs.ctl ../dasd/aspqvs.154
dasdcopy -a -o CCKD ../dasd/aspqvs.154 ../dasd/aspqvs.154.cckd
rm -rf ../dasd/aspqvs.154

# ---- aspdlb.250.cckd ----
dasdload -a ../ctl/aspdlb.ctl ../dasd/aspdlb.250
dasdcopy -a -o CCKD ../dasd/aspdlb.250 ../dasd/aspdlb.250.cckd
rm -rf ../dasd/aspdlb.250

# ---- perma0.158.cckd ----
dasdload -a ../ctl/perma0.ctl ../dasd/perma0.158
dasdcopy -a -o CCKD ../dasd/perma0.158 ../dasd/perma0.158.cckd
rm -rf ../dasd/perma0.158

# ---- worka0.159.cckd ----
dasdload -a ../ctl/worka0.ctl ../dasd/worka0.159
dasdcopy -a -o CCKD ../dasd/worka0.159 ../dasd/worka0.159.cckd
rm -rf ../dasd/worka0.159

# ---- sorta0.130.cckd ----
dasdload -a ../ctl/sorta0.ctl ../dasd/sorta0.130
dasdcopy -a -o CCKD ../dasd/sorta0.130 ../dasd/sorta0.130.cckd
rm -rf ../dasd/sorta0.130

@rem ---- spool1.152.cckd ----
dasdload -a ../ctl/spool1.ctl ../dasd/spool1.152
dasdcopy -a -o CCKD ../dasd/spool1.152 ../dasd/spool1.152.cckd
rm -rf ../dasd/spool1.152
